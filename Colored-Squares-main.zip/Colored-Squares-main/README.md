# Colored-Squares

Video Link:  https://www.youtube.com/watch?v=VsjsSdfeEOI&t=8s

Subscribe our channel and like our videos https://www.youtube.com/c/Angulars
