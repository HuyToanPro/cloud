# Video mô phỏng dao động điều hoà
Video sử dụng thư viện Manim của Python. Tìm hiểu về manim tại đây https://github.com/ManimCommunity/manim
